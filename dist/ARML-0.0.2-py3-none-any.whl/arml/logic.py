def dif(a, b):
    return a-b
    