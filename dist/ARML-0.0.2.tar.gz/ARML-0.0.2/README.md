# ARML
This repository contains special code for utilization of ML models for time series forecasting 
